/***************************
This is JavaScript (JS), the programming language that powers the web (and this is a comment, which you can delete).

To use this file, link it to your markup by placing a <script> in the <body> of your HTML file:

  <body>
    <script src="script.js"></script>

replacing "script.js" with the name of this JS file.

Learn more about JavaScript at

https://developer.mozilla.org/en-US/Learn/JavaScript
***************************/

function greetMe(name) {
  var today = new Date();
  alert("Hello " + name + ", today is " + today.toDateString());
}

//greetMe("World");

function startgames() {
  console.log('Game started')
  var secretnum = Math.random()*10;
  secretnum = Math.floor(secretnum);
  console.log(secretnum)
  var lives = 5;
  var won = false;
  function name() {
  var input = document.getElementById("userin");
  alert(input);
}

  while (lives > 0 && !won) {
  
}
var gamebutton = document.querySelector('#startgame');
gamebutton.addEventListener('click', startgames);

